﻿# Should be located in %DocumentFolder%\WindowsPowerShall folder by mklink

function ps-default {
    start PowerShell_ISE $PSScriptRoot\ps-default.psm1
}

function ps-local {
    start PowerShell_ISE $PSScriptRoot\ps-local.psm1
}

function ps-profile {
    start PowerShell_ISE $PSScriptRoot\Microsoft.PowerShell_profile.ps1
}

function npp { 
    $path = $args[0]

    if ($path) {
        start notepad++ $path
    }
    else {
        start notepad++
    }
}

function en-ru {
    translate -path "https://translate.google.com/#en/ru/" -words $args
}

function ru-en {
    translate -path "https://translate.google.com/#ru/en/" -words $args
}

function translate {
    Param([string]$path,[string[]]$words)

    $text = [string]::Join(" ", $words)
    $fullPath = $path + $text

    start $fullPath
}

function search {
    $path = "https://www.google.com/search?q="
    $query = [string]::Join("+", $args)
    $fullPath = $path + $query

    start $fullPath
}

function open-projects {
    Write-Host " " 
    Write-Host "Listing all visual studio solutions" -ForegroundColor yellow
    Write-Host " " 
    Add-Type @'
    public class solution
    {
        public int id;
        public string name;
        public string fullname;
    }
'@
    $tempSolutions = Get-ChildItem D:\Projects -Recurse -Include *.sln | select Name, FullName 
    $si = New-Object solution
    $st = [Type] $si.GetType()
    $base = [System.Collections.Generic.List``1]
    $qt = $base.MakeGenericType(@($st))
    $so = [Activator]::CreateInstance($qt)
    for($i = 0; $i -lt $tempSolutions.Count; $i++)
    {
        $obj = New-Object solution
        $obj.id = $i
        $obj.name = $tempSolutions[$i].Name
        $obj.fullname = $tempSolutions[$i].FullName
        $so.Add($obj)
    }
    $so | Format-Table -AutoSize
    $choice = Read-Host "Enter a number to open a vs solution or letter x to exit" 
    if($choice -eq "x"){
        Write-Host -ForegroundColor red "exited selection" -BackgroundColor black
    }
    else
    {
        Write-Host -ForegroundColor Yellow "Opening VS solution:" $so[$choice].name
        Start-Process $so[$choice].fullname
    }
}

function add-path {
    Param([string]$path, [string]$target)
	
    $target = $target.ToLower()
    if ($target -eq "u" -or [string]::IsNullOrEmpty($target)) { $envVeriableTarget = [EnvironmentVariableTarget]::User }
	elseif ($target -eq "m") { $envVeriableTarget = [EnvironmentVariableTarget]::Machine }

    $newEnvPath = $env:Path + ";" + $path
    [Environment]::SetEnvironmentVariable("Path", $newEnvPath, $envVeriableTarget)
}


function get-path {
    Param([string]$target)
    
    $target = $target.ToLower()
    if ($target -eq "u" -or [string]::IsNullOrEmpty($target)) { $envVeriableTarget = [EnvironmentVariableTarget]::User }
	elseif ($target -eq "m") { $envVeriableTarget = [EnvironmentVariableTarget]::Machine }

    [Environment]::GetEnvironmentVariable("Path", $envVeriableTarget)
}

function ef-migration-create {
    Param([string]$migrationName)

    dotnet ef migrations add $migrationName
}

function ef-migration-update {
    Param([string]$migrationName)

    if ($null -ne $migrationName) { 
        dotnet ef database update $migrationName
    }
    else {
        dotnet ef database update
    }
}

function ef-migration-revert {
    dotnet ef migrations remove
}

function ef-migration-list {
    dotnet ef migrations list
}

function docker-up {
    Param([string]$composeFilePath)

    if ([string]::IsNullOrWhiteSpace($composeFilePath)) {
        docker compose up --build -d
    }
    else {
        docker compose -f $composeFilePath up --build -d
    }
}

function docker-down {
    Param([string]$composeFilePath)
    
    if ([string]::IsNullOrWhiteSpace($composeFilePath)) {
        docker compose down
    }
    else {
        docker compose -f $composeFilePath down
    }
}

function docker-start {
    Param([string]$composeFilePath)
    
    if ([string]::IsNullOrWhiteSpace($composeFilePath)) {
        docker compose start
    }
    else {
        docker compose -f $composeFilePath start
    }
}

function docker-stop {
    Param([string]$composeFilePath)
    
    if ([string]::IsNullOrWhiteSpace($composeFilePath)) {
        docker compose stop
    }
    else {
        docker compose -f $composeFilePath stop
    }
}

function docker-up-local {
    docker-up ".\docker-compose.local.yml"
}


function docker-down-local {
    docker-down ".\docker-compose.local.yml"
}


function docker-start-local {
    docker-start ".\docker-compose.local.yml"
}


function docker-stop-local {
    docker-stop ".\docker-compose.local.yml"
}